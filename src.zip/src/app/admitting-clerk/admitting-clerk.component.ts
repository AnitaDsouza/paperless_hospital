import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admitting-clerk',
  templateUrl: './admitting-clerk.component.html',
  styleUrls: ['./admitting-clerk.component.css']
})
export class AdmittingClerkComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
