import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdmittingClerkComponent } from './admitting-clerk.component';

describe('AdmittingClerkComponent', () => {
  let component: AdmittingClerkComponent;
  let fixture: ComponentFixture<AdmittingClerkComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdmittingClerkComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdmittingClerkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
