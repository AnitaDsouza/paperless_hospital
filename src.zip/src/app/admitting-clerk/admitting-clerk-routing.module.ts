import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdmittingClerkComponent } from './admitting-clerk.component';

const routes: Routes = [
  { 
    path: 'Admitting', 
    component: AdmittingClerkComponent,
    data: { showHeader: false, showSidebar: false, showHeader2:"true" } 
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdmittingClerkRoutingModule { }
