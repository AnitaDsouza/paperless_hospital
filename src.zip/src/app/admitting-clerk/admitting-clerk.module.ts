import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdmittingClerkRoutingModule } from './admitting-clerk-routing.module';
import { AdmittingClerkComponent } from './admitting-clerk.component';
import {FlexLayoutModule} from '@angular/flex-layout';

@NgModule({
  declarations: [AdmittingClerkComponent],
  imports: [
    CommonModule,
    AdmittingClerkRoutingModule,
    FlexLayoutModule
  ]
})
export class AdmittingClerkModule { }
