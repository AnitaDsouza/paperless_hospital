import { Component, OnInit } from '@angular/core';
 import 'src/assets/try2.js';

@Component({
  selector: 'app-department-clerk',
  templateUrl: './department-clerk.component.html',
  styleUrls: ['./department-clerk.component.css']
})
export class DepartmentClerkComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
