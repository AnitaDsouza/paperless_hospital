import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DepartmentClerkComponent } from './department-clerk.component';

describe('DepartmentClerkComponent', () => {
  let component: DepartmentClerkComponent;
  let fixture: ComponentFixture<DepartmentClerkComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DepartmentClerkComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DepartmentClerkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
