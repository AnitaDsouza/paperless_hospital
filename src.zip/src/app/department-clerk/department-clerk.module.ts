import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DepartmentClerkRoutingModule } from './department-clerk-routing.module';
import { DepartmentClerkComponent } from './department-clerk.component';
import {FlexLayoutModule} from '@angular/flex-layout';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [ DepartmentClerkComponent],
  imports: [
    CommonModule,
    DepartmentClerkRoutingModule,
    FlexLayoutModule,
    FormsModule

    
  ]
})
export class DepartmentClerkModule { }
