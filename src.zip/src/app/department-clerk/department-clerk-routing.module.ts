import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DepartmentClerkComponent } from './department-clerk.component';
const routes: Routes = [
  { 
    path: 'Department', 
    component: DepartmentClerkComponent ,
    data: { showHeader:false, showSidebar: false } 
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DepartmentClerkRoutingModule { }
