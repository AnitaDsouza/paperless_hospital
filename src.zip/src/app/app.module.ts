import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { RouterModule } from '@angular/router';
import { LayoutModule } from './layout/layout.module';
import { AppRoutingModule } from './app-routing.module';
import { FlexLayoutModule } from '@angular/flex-layout';
import { AccountSettingsModule } from './account-settings/account-settings.module';
import { LoginModule } from './login/login.module';
import { RegistrationModule } from './registration/registration.module';
import { UsersModule } from './users/users.module';
import { DashboardModule } from './dashboard/dashboard.module';
import { AdmittingClerkModule } from './admitting-clerk/admitting-clerk.module';
import { DepartmentClerkComponent } from './department-clerk/department-clerk.component';
import { DepartmentClerkModule } from './department-clerk/./department-clerk.module';

@NgModule({
  declarations: [
    AppComponent,
   
  
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot([]),
    AppRoutingModule,
    FlexLayoutModule,
    LayoutModule,
    DashboardModule,
    AccountSettingsModule,
    LoginModule,
    RegistrationModule,
    UsersModule,
  AdmittingClerkModule,
  DepartmentClerkModule
  
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
