var calc = require('paperless-hospital-gst-calculation');

var result = calc.addGst(1000);
console.log(result);

var result1 = calc.totalWithGst(1000);
console.log(result1);