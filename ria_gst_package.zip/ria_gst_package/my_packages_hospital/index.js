var Gst_Calculation = function(){};

Gst_Calculation.prototype.addGst = function(total){
    let gst_amount = (total * 5 )/100;
    return gst_amount;
}

Gst_Calculation.prototype.totalWithGst = function(total){
    let gst_amount = (total * 5 )/100;
    let totalAmount = total + gst_amount;
    return totalAmount;
}

module.exports = new Gst_Calculation();

